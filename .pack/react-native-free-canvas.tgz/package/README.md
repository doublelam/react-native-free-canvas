# react-native-free-canvas
Freehand sketch on canvas based on  [@shopify/react-native-skia](https://github.com/shopify/react-native-skia)

<img src="https://github.com/user-attachments/assets/240398a3-2ebf-4edc-bdf5-36812765e39b" width=200 />

## Develop and test (like npm consumers)

The published package resolves `main` / `exports` to the built **`lib/`** output. The in-repo Expo app does **not** use `file:..` (symlink into the monorepo root), because Metro would then resolve **Reanimated / Skia** from the **library’s** `node_modules` and break Expo Go.

Instead, **`yarn example:sync`** at the repo root runs `yarn build`, **`npm pack`** into **`.pack/`**, copies to **`.pack/react-native-free-canvas.tgz`**, and runs **`yarn install`** in `expo-example/`. The example depends on **`file:../.pack/react-native-free-canvas.tgz`**, i.e. the same install shape as **`npm install react-native-free-canvas`** (extracted under `node_modules`). **`.pack/`** is gitignored; run sync after clone or whenever you change library code.

**Commands (repo root):**

| Command | Purpose |
|---------|---------|
| **`yarn example:sync`** | Build, pack, reinstall the library into `expo-example` |
| **`yarn test:expo`** | Sync + start Expo with `EXPO_OFFLINE=1` |
| **`yarn test:expo:online`** | Sync + start Expo (network on; use for Expo Go install/update) |
| **`yarn expo:start`** | Start Expo only (run **`yarn example:sync`** first if the library changed) |

**Cleaner alternative (no `expo-example` in your flow):** create any Expo app elsewhere (`npx create-expo-app`), then `yarn add file:/absolute/path/to/react-native-free-canvas-2.0.0.tgz` after `yarn build && npm pack` at the library root. That is a normal consumer app with no custom Metro config.

## Install
You need to install following dependencies
```
"@shopify/react-native-skia": ">=2.0.0",
"react": ">=18.0.0",
"react-native": ">=0.72.0",
"react-native-gesture-handler": ">=2.0.0",
"react-native-reanimated": ">=3.0.0",
"react-native-worklets": ">=0.5.0"
```

## Usage
```ts
import FreeCanvas from 'react-native-free-canvas';

const App = () => {
  return (
    <>
      <FreeCanvas
        // style={{flex: 1}} 
        style={styles.flex1} //avoid using a new Object to prevent unnecessary re-rendering
      />
    </>
  )
};

```

### Make Line Smoother
```ts
import {CornerPathEffect} from '@shopify/react-native-skia';

const effects = useMemo(() => <CornerPathEffect r={32} />, []);

// Add CornerPathEffect component to pathEffect props
<FreeCanvas
  // style={{flex: 1}}
  style={styles.flex1}
  pathEffect={effects} 
/>
```

## Properties

| Property | Type | Description |
|----------|------|-------------|
| style? | `StyleProp<ViewStyle>` | Custom styles for the canvas |
| strokeColor? | string \| `SharedValue<string>` | Color of the stroke |
| strokeWidth? | number \| `SharedValue<number>` | Width of the stroke |
| backgroundColor? | string \| `SharedValue<string>` | Background color of the canvas |
| background? | React.ReactNode | Skia component for background |
| foreground? | React.ReactNode | Skia component for foreground |
| pathEffect? | React.ReactNode | Skia Path Effects (see [documentation](https://shopify.github.io/react-native-skia/docs/path-effects)) |
| zoomable? | boolean | Enable/disable zooming |
| zoomRange? | [number, number] | when `zoomable` enabled, the range of zooming scale(default: [0.5, 2]) |
| onDrawEnd? | () => void | Callback function when drawing ends |
| onTranslate? | (x: number, y: number) => void | Called on the **JS thread** when translation changes (bridged with `scheduleOnRN` from `react-native-worklets`; use normal React state updates) |
| onScale? | (scale: number) => void | Called on the **JS thread** when scale changes |
| onTransformOriginChange? | (x: number, y: number) => void | Called on the **JS thread** when pinch transform origin changes |

### Transform: translate, scale, transformOrigin

`onTranslate`, `onScale`, and `onTransformOriginChange` are normal JavaScript callbacks. They are invoked from the React Native JS runtime (not as UI-thread worklets), so you can call `setState` or other React APIs directly. High-frequency updates still follow the shared values that drive the canvas transform.

The order of the transform and scale in animated style for the Canvas while zooming should be:

```ts
{
  transform: [
    { translateX: translateSharedVal.value.x },
    { translateY: translateSharedVal.value.y },
    { scale: scaleSharedVal.value },
  ],
  transformOrigin: originSharedVal.value.concat([0]),
}
```

## Methods or Values
| Method | Parameters | Return Type | Description |
|--------|------------|-------------|-------------|
| reset | - | void | Resets the canvas |
| resetZoom | (duration?: number) | void | Resets the zoom level |
| undo | (step?: number) | `false \| number` | Undoes the last drawing action(s); returns `false` if `step` exceeds path count, otherwise the number of steps undone |
| toBase64 | (fmt?: ImageFormat, quality?: number) | Promise<string \| undefined> | Converts canvas to base64 string |
| getSnapshot | - | Promise<SkImage \| undefined> \| undefined | Gets a snapshot of the canvas |
| toPaths | - | DrawnPath[] | Returns the drawn paths |
| drawPaths | (paths: DrawnPath[]) | void | Draws the given paths on the canvas |
| translateSharedValue | - | `SharedValue<{ x: number; y: number }>` | Shared value for translation |
| scaleSharedValue | - | `SharedValue<number>` | Shared value for scale |
| transformOriginSharedValue | - | `SharedValue<[number, number]>` | Shared value for transform origin |

## Inspired By
[wobsoriano/rn-perfect-sketch-canvas](https://github.com/wobsoriano/rn-perfect-sketch-canvas) A React Native component for drawing perfect pressure-sensitive freehand lines using perfect-freehand and Skia renderer.
